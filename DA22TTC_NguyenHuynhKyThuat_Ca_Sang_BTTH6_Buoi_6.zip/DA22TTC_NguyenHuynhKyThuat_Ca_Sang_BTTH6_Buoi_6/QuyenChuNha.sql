
         SELECT * FROM DMSach;
         EXEC sp_TangLuongNhanVien;
         CREATE TABLE TestTable_Chunha (ID INT); DROP TABLE TestTable_Chunha;